package com.Mealess.appaction;

public class Book {
    public String uri;
    public String name;
    public String format;
    public String coverPath;
    public String category;
    public boolean isFavorite;
    public long lastReadTime;
    public int lastPage;
    public String bookmarks;
    public long totalReadTime; // 🚀 新增：累计阅读时长（毫秒）

    public Book(String uri, String name, String format, String coverPath, String category) {
        this.uri = uri;
        this.name = name;
        this.format = format;
        this.coverPath = coverPath;
        this.category = category;
        this.isFavorite = false;
        this.lastReadTime = System.currentTimeMillis();
        this.lastPage = 0;
        this.bookmarks = "";
        this.totalReadTime = 0;
    }
    
    public static String extOf(String name) {
        if (name == null) return "";
        int i = name.lastIndexOf('.');
        if (i < 0 || i == name.length() - 1) return "";
        return name.substring(i + 1).toLowerCase();
    }
}