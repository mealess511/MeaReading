package com.Mealess.appaction;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;

public class BookStorage {
    private static final String PREF_NAME = "bookshelf_data";
    private static final String KEY_BOOKS = "all_books";

    public static void saveBooks(Context context, List<Book> books) {
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        StringBuilder sb = new StringBuilder();
        for (Book b : books) {
            String safeName = b.name.replace("\n", " ");
            sb.append(b.uri).append("||")
              .append(safeName).append("||")
              .append(b.format).append("||")
              .append(b.coverPath == null ? "" : b.coverPath).append("||")
              .append(b.category).append("||")
              .append(b.isFavorite).append("||")
              .append(b.lastReadTime).append("||")
              .append(b.lastPage).append("||")
              .append(b.bookmarks == null ? "" : b.bookmarks).append("||")
              .append(b.totalReadTime).append("\n"); // 🚀 保存时长
        }
        sp.edit().putString(KEY_BOOKS, sb.toString()).commit();
    }

    public static List<Book> loadBooks(Context context) {
        List<Book> books = new ArrayList<>();
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String data = sp.getString(KEY_BOOKS, "");
        if (data.isEmpty()) return books;

        String[] lines = data.split("\n");
        for (String line : lines) {
            if (line.trim().isEmpty()) continue;
            
            String[] p = line.split("\\|\\|", -1); 
            if (p.length >= 8) {
                try {
                    Book b = new Book(p[0], p[1], p[2], p[3].isEmpty() ? null : p[3], p[4]);
                    b.isFavorite = Boolean.parseBoolean(p[5]);
                    b.lastReadTime = Long.parseLong(p[6]);
                    b.lastPage = Integer.parseInt(p[7]);
                    if (p.length >= 9) b.bookmarks = p[8];
                    // 🚀 兼容旧数据，如果第10个字段存在，读取时长
                    if (p.length >= 10) b.totalReadTime = Long.parseLong(p[9]);
                    books.add(b);
                } catch (Exception e) {}
            }
        }
        return books;
    }
}