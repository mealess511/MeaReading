package com.Mealess.appaction;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends Activity {

    private ListView listBooks;
    private TextView tvEmpty, tabNovel, tabComic, tabHistory, tabFavorite;
    private TextView btnImport, btnClearCache, btnBgSetting;
    private EditText etSearch;
    private View mainRoot;
    
    private final List<Book> allBooks = new ArrayList<>();
    private final List<Book> displayBooks = new ArrayList<>();
    private BookAdapter adapter;
    
    private String currentTab = "NOVEL"; 
    private String searchQuery = "";
    private static final int REQ_OPEN = 1001;
    private static final int REQ_COVER = 1002;
    private static final int REQ_BG = 1003;

    private Book pendingCoverBook = null; 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainRoot = findViewById(R.id.mainRoot);
        listBooks = findViewById(R.id.listBooks);
        tvEmpty = findViewById(R.id.tvEmpty);
        tabNovel = findViewById(R.id.tabNovel);
        tabComic = findViewById(R.id.tabComic);
        tabHistory = findViewById(R.id.tabHistory);
        tabFavorite = findViewById(R.id.tabFavorite);
        btnImport = findViewById(R.id.btnImport);
        btnClearCache = findViewById(R.id.btnClearCache);
        btnBgSetting = findViewById(R.id.btnBgSetting);
        etSearch = findViewById(R.id.etSearch);

        adapter = new BookAdapter();
        listBooks.setAdapter(adapter);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s.toString().trim().toLowerCase();
                filterBooks();
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        tabNovel.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { switchTab("NOVEL"); } });
        tabComic.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { switchTab("COMIC"); } });
        tabHistory.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { switchTab("HISTORY"); } });
        tabFavorite.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { switchTab("FAVORITE"); } });

        btnImport.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { pickFile(); } });
        btnClearCache.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { clearAppCache(); } });

        btnBgSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] items = {"默认纯白", "高级浅灰", "护眼淡绿", "夜间深黑", "从相册选择背景图"};
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("选择首页背景风格")
                    .setItems(items, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            getSharedPreferences("app_settings", MODE_PRIVATE).edit().putString("bg_uri", null).apply();
                            if (which == 0) mainRoot.setBackgroundColor(0xFFFFFFFF);
                            else if (which == 1) mainRoot.setBackgroundColor(0xFFF7F8FA);
                            else if (which == 2) mainRoot.setBackgroundColor(0xFFE8F5E9);
                            else if (which == 3) mainRoot.setBackgroundColor(0xFF121212);
                            else if (which == 4) {
                                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                                i.addCategory(Intent.CATEGORY_OPENABLE);
                                i.setType("image/*");
                                try { startActivityForResult(i, REQ_BG); } catch (Exception e) {}
                            }
                        }
                    }).show();
            }
        });

        applyBackground();
        loadData();
        switchTab("NOVEL");
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
        filterBooks();
    }

    private void loadData() {
        allBooks.clear();
        allBooks.addAll(BookStorage.loadBooks(this));
    }

    // 🚀 核心修复 1：让背景图按 CENTER_CROP 缩放，保证不拉伸
    private void applyBackground() {
        SharedPreferences sp = getSharedPreferences("app_settings", MODE_PRIVATE);
        String bgUri = sp.getString("bg_uri", null);
        if (bgUri != null) {
            try {
                InputStream is = getContentResolver().openInputStream(Uri.parse(bgUri));
                Bitmap bmp = BitmapFactory.decodeStream(is);
                if (is != null) is.close();
                
                if (bmp != null) {
                    BitmapDrawable drawable = new BitmapDrawable(getResources(), bmp);
                    // 设置为等比填满屏幕并裁剪多余部分，绝不拉伸变形
                    drawable.setGravity(android.view.Gravity.FILL); 
                    mainRoot.setBackground(drawable);
                    return;
                }
            } catch (Exception ignored) {}
        }
        mainRoot.setBackgroundColor(0xFFF7F8FA);
    }

    private void showBookOptions(final Book book) {
        String[] options = {"修改书名(昵称)", "更换封面", "删除书籍"};
        new AlertDialog.Builder(this)
            .setTitle(book.name)
            .setItems(options, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if (which == 0) {
                        final EditText et = new EditText(MainActivity.this);
                        et.setText(book.name);
                        new AlertDialog.Builder(MainActivity.this).setTitle("修改书名(仅作显示)").setView(et)
                            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                @Override public void onClick(DialogInterface d, int w) {
                                    book.name = et.getText().toString();
                                    BookStorage.saveBooks(MainActivity.this, allBooks);
                                    filterBooks();
                                }
                            }).setNegativeButton("取消", null).show();
                    } else if (which == 1) {
                        pendingCoverBook = book;
                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("image/*");
                        try { startActivityForResult(intent, REQ_COVER); } catch (Exception e) {}
                    } else if (which == 2) {
                        new AlertDialog.Builder(MainActivity.this).setTitle("删除").setMessage("确定移出书架吗？")
                            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                @Override public void onClick(DialogInterface d, int w) {
                                    allBooks.remove(book);
                                    BookStorage.saveBooks(MainActivity.this, allBooks);
                                    filterBooks();
                                }
                            }).setNegativeButton("取消", null).show();
                    }
                }
            }).show();
    }

    private void clearAppCache() {
        File cacheDir = getCacheDir();
        long totalSize = 0;
        if (cacheDir != null && cacheDir.isDirectory()) {
            File[] files = cacheDir.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.getName().startsWith("tmp_")) {
                        totalSize += file.length();
                        file.delete();
                    }
                }
            }
        }
        long mb = totalSize / (1024 * 1024);
        Toast.makeText(this, "清理完成！释放了 " + mb + " MB 空间", Toast.LENGTH_SHORT).show();
    }

    private void switchTab(String tab) {
        currentTab = tab;
        int activeColor = 0xFF1A1A1A;
        int inactiveColor = 0xFF8A8A8A;
        tabNovel.setTextColor(tab.equals("NOVEL") ? activeColor : inactiveColor);
        tabComic.setTextColor(tab.equals("COMIC") ? activeColor : inactiveColor);
        tabHistory.setTextColor(tab.equals("HISTORY") ? activeColor : inactiveColor);
        tabFavorite.setTextColor(tab.equals("FAVORITE") ? activeColor : inactiveColor);

        tabNovel.setTypeface(null, tab.equals("NOVEL") ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        tabComic.setTypeface(null, tab.equals("COMIC") ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        tabHistory.setTypeface(null, tab.equals("HISTORY") ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        tabFavorite.setTypeface(null, tab.equals("FAVORITE") ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);

        filterBooks();
    }

    private void filterBooks() {
        displayBooks.clear();
        for (Book b : allBooks) {
            boolean matchesTab = false;
            if (currentTab.equals("NOVEL") && b.category.equals("NOVEL")) matchesTab = true;
            else if (currentTab.equals("COMIC") && b.category.equals("COMIC")) matchesTab = true;
            else if (currentTab.equals("FAVORITE") && b.isFavorite) matchesTab = true;
            else if (currentTab.equals("HISTORY") && b.lastReadTime > 0) matchesTab = true;

            if (matchesTab) {
                if (searchQuery.isEmpty() || b.name.toLowerCase().contains(searchQuery)) {
                    displayBooks.add(b);
                }
            }
        }
        
        if (currentTab.equals("HISTORY")) {
            java.util.Collections.sort(displayBooks, new java.util.Comparator<Book>() {
                @Override public int compare(Book b1, Book b2) {
                    return Long.compare(b2.lastReadTime, b1.lastReadTime);
                }
            });
        }

        adapter.notifyDataSetChanged();
        tvEmpty.setVisibility(displayBooks.isEmpty() ? View.VISIBLE : View.GONE);
        listBooks.setVisibility(displayBooks.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try { startActivityForResult(i, REQ_OPEN); } catch (Exception e) {}
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;

            if (requestCode == REQ_OPEN) {
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
                String name = queryName(uri);
                String ext = Book.extOf(name);
                
                if (name == null || name.trim().isEmpty() || name.equals("未命名")) {
                    Random rand = new Random();
                    name = "未命名书籍_" + (1000 + rand.nextInt(9000));
                }
                
                String category = "NOVEL";
                if (ext.equals("zip") || ext.equals("cbz") || ext.equals("cbr")) category = "COMIC";
                else if (ext.equals("pdf") || ext.equals("epub")) category = currentTab.equals("COMIC") ? "COMIC" : "NOVEL";

                for (Book b : allBooks) {
                    if (b.uri.equals(uri.toString())) {
                        Toast.makeText(this, "该书籍已存在", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                Book newBook = new Book(uri.toString(), name, ext, null, category);
                allBooks.add(0, newBook);
                BookStorage.saveBooks(MainActivity.this, allBooks);
                Toast.makeText(this, "导入成功！", Toast.LENGTH_SHORT).show();
                switchTab(category); 

            } else if (requestCode == REQ_COVER && pendingCoverBook != null) {
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
                pendingCoverBook.coverPath = uri.toString();
                BookStorage.saveBooks(MainActivity.this, allBooks);
                filterBooks();
                Toast.makeText(this, "封面更换成功！", Toast.LENGTH_SHORT).show();
                pendingCoverBook = null;

            } else if (requestCode == REQ_BG) {
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
                getSharedPreferences("app_settings", MODE_PRIVATE).edit().putString("bg_uri", uri.toString()).apply();
                applyBackground();
            }
        }
    }

    private String queryName(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception ignored) {} finally { if (c != null) c.close(); }
        return uri.getLastPathSegment();
    }

    private class BookAdapter extends BaseAdapter {
        @Override public int getCount() { return displayBooks.size(); }
        @Override public Object getItem(int p) { return displayBooks.get(p); }
        @Override public long getItemId(int p) { return p; }

        @Override public View getView(int p, View cv, ViewGroup parent) {
            LinearLayout layout = new LinearLayout(MainActivity.this);
            layout.setOrientation(LinearLayout.HORIZONTAL);
            layout.setPadding(24, 24, 24, 24);
            layout.setBackgroundResource(R.drawable.bg_card);
            layout.setGravity(android.view.Gravity.CENTER_VERTICAL);
            
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, 20);
            layout.setLayoutParams(lp);

            final Book b = displayBooks.get(p);

            FrameLayout coverContainer = new FrameLayout(MainActivity.this);
            LinearLayout.LayoutParams ivLp = new LinearLayout.LayoutParams(140, 190);
            ivLp.setMargins(0, 0, 24, 0);
            coverContainer.setLayoutParams(ivLp);
            coverContainer.setBackgroundColor(0xFFF0F2F5);

            if (b.coverPath != null && !b.coverPath.isEmpty()) {
                ImageView iv = new ImageView(MainActivity.this);
                iv.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                
                // 🚀 核心修复 2：改为 FIT_CENTER，保证原图比例显示，不拉伸不裁剪
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER); 
                try { iv.setImageURI(Uri.parse(b.coverPath)); } catch (Exception e) {}
                coverContainer.addView(iv);
            } else {
                TextView tvCover = new TextView(MainActivity.this);
                tvCover.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                tvCover.setGravity(android.view.Gravity.CENTER);
                tvCover.setText("📖");
                tvCover.setTextSize(32);
                coverContainer.addView(tvCover);
            }

            LinearLayout textLayout = new LinearLayout(MainActivity.this);
            textLayout.setOrientation(LinearLayout.VERTICAL);
            textLayout.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            
            TextView t1 = new TextView(MainActivity.this);
            t1.setText(b.name);
            t1.setTextSize(16);
            t1.setTextColor(0xFF1A1A1A);
            t1.setTypeface(null, android.graphics.Typeface.BOLD);
            t1.setMaxLines(2);
            t1.setEllipsize(android.text.TextUtils.TruncateAt.END);
            
            TextView t2 = new TextView(MainActivity.this);
            long min = b.totalReadTime / (1000 * 60);
            String timeStr = min > 0 ? "  ·  已读 " + min + " 分钟" : "";
            t2.setText(b.format.toUpperCase() + "  ·  进度 " + b.lastPage + timeStr);
            t2.setTextSize(12);
            t2.setTextColor(0xFF8A8A8A);
            t2.setPadding(0, 12, 0, 0);
            
            TextView t3 = new TextView(MainActivity.this);
            String realName = b.uri;
            if (realName != null && realName.contains("/")) {
                realName = realName.substring(realName.lastIndexOf("/") + 1);
            }
            try { realName = java.net.URLDecoder.decode(realName, "UTF-8"); } catch (Exception ignored) {}
            t3.setText("文件: " + realName);
            t3.setTextSize(10);
            t3.setTextColor(0xFFB0B0B0);
            t3.setPadding(0, 4, 0, 0);
            t3.setSingleLine(true);
            t3.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            
            textLayout.addView(t1);
            textLayout.addView(t2);
            textLayout.addView(t3);

            LinearLayout btnArea = new LinearLayout(MainActivity.this);
            btnArea.setOrientation(LinearLayout.HORIZONTAL);
            btnArea.setGravity(android.view.Gravity.CENTER_VERTICAL);
            btnArea.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT));

            TextView btnStar = new TextView(MainActivity.this);
            btnStar.setLayoutParams(new LinearLayout.LayoutParams(60, LinearLayout.LayoutParams.MATCH_PARENT));
            btnStar.setGravity(android.view.Gravity.CENTER);
            btnStar.setText(b.isFavorite ? "⭐" : "☆");
            btnStar.setTextSize(24);
            btnStar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    b.isFavorite = !b.isFavorite;
                    BookStorage.saveBooks(MainActivity.this, allBooks);
                    filterBooks();
                }
            });

            TextView btnMore = new TextView(MainActivity.this);
            btnMore.setLayoutParams(new LinearLayout.LayoutParams(60, LinearLayout.LayoutParams.MATCH_PARENT));
            btnMore.setGravity(android.view.Gravity.CENTER);
            btnMore.setText("⋮");
            btnMore.setTextColor(0xFF1A1A1A);
            btnMore.setTextSize(28);
            btnMore.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showBookOptions(b);
                }
            });

            btnArea.addView(btnStar);
            btnArea.addView(btnMore);

            layout.addView(coverContainer);
            layout.addView(textLayout);
            layout.addView(btnArea);
            
            layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    b.lastReadTime = System.currentTimeMillis();
                    BookStorage.saveBooks(MainActivity.this, allBooks);
                    
                    Intent intent = new Intent(MainActivity.this, ReaderActivity.class);
                    intent.putExtra("book_uri", b.uri);
                    intent.putExtra("book_name", b.name);
                    startActivity(intent);
                }
            });
            
            return layout;
        }
    }
}