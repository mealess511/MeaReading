package com.Mealess.appaction;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.Mealess.appaction.parser.Parser;
import com.Mealess.appaction.parser.ParserFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class ReaderActivity extends Activity {

    private FrameLayout pageContainer, readerRoot;
    private LinearLayout topBar, bottomBar;
    private TextView tvTitle, tvPageInfo, btnModeHorizontal, btnModeVertical, btnClickReverse, btnShowBookmarks, btnAddBookmark, btnFav, btnToc;
    private SeekBar sbBrightness, sbFontSize, sbProgress;
    private View loadingBar;

    private Parser parser;
    private Book currentBook;
    private int currentPage = 0;
    private int fontSize = 18;
    private boolean barsVisible = false;
    
    private int mode = 0; 
    private boolean isClickReversed = false; 
    private int bgColorIndex = 1; 

    private GestureDetector gestureDetector;
    private boolean isTracking = false;

    private ScrollView mScrollView;
    private LinearLayout mContentLayout;
    private int loadedEndPage = 0;
    private boolean isLoadingMore = false;

    private long readingStartTime = 0;

    private List<Integer> chapterPages = new ArrayList<>();
    private List<String> chapterNames = new ArrayList<>();
    private boolean isTocParsing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reader);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);

        initViews();
        
        // 🚀 修复点：将局部变量转为 final，防止 AIDE 老版本编译器报错
        final String uri = getIntent().getStringExtra("book_uri");
        String name = getIntent().getStringExtra("book_name");
        
        tvTitle.setText(name);

        List<Book> allBooks = BookStorage.loadBooks(this);
        for (Book b : allBooks) {
            if (b.uri.equals(uri)) {
                currentBook = b;
                break;
            }
        }
        
        // 🚀 修复点：把 currentBook 存为一个 final 变量供子线程使用
        final Book safeBook = currentBook;
        
        if (safeBook != null) {
            btnFav.setText(safeBook.isFavorite ? "⭐" : "☆");
        }

        loadingBar.setVisibility(View.VISIBLE);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    int pageChars = 1000;
                    // 这里使用 safeBook 替代 currentBook，使用 uri 替代局部变量
                    final Parser p = ParserFactory.create(ReaderActivity.this, uri, safeBook.format, pageChars);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            parser = p;
                            currentPage = (safeBook != null) ? safeBook.lastPage : 0;
                            if (currentPage >= parser.pageCount()) currentPage = 0;
                            renderPage();
                            loadingBar.setVisibility(View.GONE);
                            
                            if (!parser.isImageBased()) {
                                parseChapters();
                            }
                        }
                    });
                } catch (final Throwable t) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            loadingBar.setVisibility(View.GONE);
                            Toast.makeText(ReaderActivity.this, "打开失败：" + t.getMessage(), Toast.LENGTH_LONG).show();
                            finish();
                        }
                    });
                }
            }
        }).start();
    }

    private void initViews() {
        pageContainer = findViewById(R.id.pageContainer);
        readerRoot = findViewById(R.id.readerRoot);
        topBar = findViewById(R.id.topBar);
        bottomBar = findViewById(R.id.bottomBar);
        tvTitle = findViewById(R.id.tvTitle);
        tvPageInfo = findViewById(R.id.tvPageInfo);
        sbBrightness = findViewById(R.id.sbBrightness);
        sbFontSize = findViewById(R.id.sbFontSize);
        sbProgress = findViewById(R.id.sbProgress);
        btnModeHorizontal = findViewById(R.id.btnModeHorizontal);
        btnModeVertical = findViewById(R.id.btnModeVertical);
        btnClickReverse = findViewById(R.id.btnClickReverse);
        btnShowBookmarks = findViewById(R.id.btnShowBookmarks);
        btnAddBookmark = findViewById(R.id.btnAddBookmark);
        btnFav = findViewById(R.id.btnFav);
        btnToc = findViewById(R.id.btnToc);
        loadingBar = findViewById(R.id.loadingBar);

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });

        btnToc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (parser == null) return;
                if (parser.isImageBased()) {
                    Toast.makeText(ReaderActivity.this, "漫画/PDF暂不支持目录", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (isTocParsing) {
                    Toast.makeText(ReaderActivity.this, "正在解析目录，请稍候...", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (chapterNames.isEmpty()) {
                    Toast.makeText(ReaderActivity.this, "未识别到章节", Toast.LENGTH_SHORT).show();
                    return;
                }
                
                String[] display = chapterNames.toArray(new String[0]);
                new AlertDialog.Builder(ReaderActivity.this)
                    .setTitle("目录")
                    .setItems(display, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            currentPage = chapterPages.get(which);
                            renderPage();
                        }
                    }).show();
            }
        });

        btnFav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentBook != null) {
                    currentBook.isFavorite = !currentBook.isFavorite;
                    btnFav.setText(currentBook.isFavorite ? "⭐" : "☆");
                    BookStorage.saveBooks(ReaderActivity.this, getUpdatedBooks(currentBook));
                    Toast.makeText(ReaderActivity.this, currentBook.isFavorite ? "已加入收藏" : "已取消收藏", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnAddBookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentBook != null) {
                    String bm = currentBook.bookmarks == null ? "" : currentBook.bookmarks;
                    if (!bm.contains(String.valueOf(currentPage))) {
                        currentBook.bookmarks = bm.isEmpty() ? String.valueOf(currentPage) : bm + "," + currentPage;
                        BookStorage.saveBooks(ReaderActivity.this, getUpdatedBooks(currentBook));
                        Toast.makeText(ReaderActivity.this, "已添加书签", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(ReaderActivity.this, "当前页已经有书签了", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        btnShowBookmarks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentBook == null || currentBook.bookmarks == null || currentBook.bookmarks.isEmpty()) {
                    Toast.makeText(ReaderActivity.this, "还没有书签哦", Toast.LENGTH_SHORT).show();
                    return;
                }
                final String[] bms = currentBook.bookmarks.split(",");
                String[] display = new String[bms.length];
                for (int i = 0; i < bms.length; i++) {
                    display[i] = "第 " + (Integer.parseInt(bms[i]) + 1) + " 页";
                }
                new AlertDialog.Builder(ReaderActivity.this)
                    .setTitle("选择书签")
                    .setItems(display, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            currentPage = Integer.parseInt(bms[which]);
                            renderPage();
                        }
                    })
                    .setNegativeButton("清空书签", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            currentBook.bookmarks = "";
                            BookStorage.saveBooks(ReaderActivity.this, getUpdatedBooks(currentBook));
                            Toast.makeText(ReaderActivity.this, "书签已清空", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .show();
            }
        });

        sbProgress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) { 
                    currentPage = progress; 
                    renderPage();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { isTracking = true; }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { isTracking = false; }
        });

        sbBrightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.screenBrightness = Math.max(0.01f, Math.min(1f, progress / 100f));
                getWindow().setAttributes(lp);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        sbFontSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) { fontSize = 12 + progress; renderPage(); }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnModeHorizontal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mode = 0;
                btnModeHorizontal.setTextColor(0xFF000000);
                btnModeHorizontal.setTypeface(null, android.graphics.Typeface.BOLD);
                btnModeVertical.setTextColor(0xFF999999);
                btnModeVertical.setTypeface(null, android.graphics.Typeface.NORMAL);
                if (parser != null) renderPage();
            }
        });

        btnModeVertical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mode = 1;
                btnModeVertical.setTextColor(0xFF000000);
                btnModeVertical.setTypeface(null, android.graphics.Typeface.BOLD);
                btnModeHorizontal.setTextColor(0xFF999999);
                btnModeHorizontal.setTypeface(null, android.graphics.Typeface.NORMAL);
                if (parser != null) renderPage();
            }
        });

        btnClickReverse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isClickReversed = !isClickReversed;
                btnClickReverse.setText(isClickReversed ? "左侧下一页" : "右侧下一页");
            }
        });

        findViewById(R.id.color0).setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { bgColorIndex = 0; if (parser != null) renderPage(); } });
        findViewById(R.id.color1).setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { bgColorIndex = 1; if (parser != null) renderPage(); } });
        findViewById(R.id.color2).setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { bgColorIndex = 2; if (parser != null) renderPage(); } });
        findViewById(R.id.color3).setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { bgColorIndex = 3; if (parser != null) renderPage(); } });

        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                if (parser == null) return false;
                int w = getResources().getDisplayMetrics().widthPixels;
                float x = e.getX();
                if (x > w * 0.35f && x < w * 0.65f) {
                    toggleBars();
                } else if (mode == 0) {
                    if ((x < w * 0.35f && !isClickReversed) || (x > w * 0.65f && isClickReversed)) {
                        prevPage();
                    } else {
                        nextPage();
                    }
                } else {
                    toggleBars();
                }
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                if (e1 == null || e2 == null || mode == 1 || parser == null) return false;
                float dx = e2.getX() - e1.getX();
                float dy = e2.getY() - e1.getY();
                if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 80) {
                    boolean isSwipeLeft = dx < 0;
                    if (isSwipeLeft) {
                        if (!isClickReversed) nextPage(); else prevPage();
                    } else {
                        if (!isClickReversed) prevPage(); else nextPage();
                    }
                    return true;
                }
                return false;
            }
        });
    }

    private void parseChapters() {
        isTocParsing = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<Integer> pages = new ArrayList<>();
                final List<String> names = new ArrayList<>();
                Pattern pattern = Pattern.compile("^\\s*第[0-9一二三四五六七八九十百千万]+[章回节卷].*");
                
                int count = parser.pageCount();
                for (int i = 0; i < count; i++) {
                    String text = parser.getTextPage(i).toString();
                    String[] lines = text.split("\n");
                    for (String line : lines) {
                        line = line.trim();
                        if (pattern.matcher(line).matches()) {
                            pages.add(i);
                            names.add(line);
                            break;
                        }
                    }
                }
                
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        chapterPages.clear();
                        chapterPages.addAll(pages);
                        chapterNames.clear();
                        chapterNames.addAll(names);
                        isTocParsing = false;
                    }
                });
            }
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        readingStartTime = System.currentTimeMillis();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (currentBook != null && parser != null) {
            long cost = System.currentTimeMillis() - readingStartTime;
            if (cost > 0 && cost < 4 * 60 * 60 * 1000) {
                currentBook.totalReadTime += cost;
            }
            
            currentBook.lastPage = currentPage;
            currentBook.lastReadTime = System.currentTimeMillis();
            BookStorage.saveBooks(this, getUpdatedBooks(currentBook));
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (gestureDetector != null && gestureDetector.onTouchEvent(ev)) return true;
        return super.dispatchTouchEvent(ev);
    }

    private void renderPage() {
        pageContainer.removeAllViews();
        if (parser == null) return;
        int count = parser.pageCount();
        if (count == 0) return;
        if (currentPage < 0) currentPage = 0;
        if (currentPage >= count) currentPage = count - 1;

        if (!isTracking) {
            sbProgress.setMax(count - 1);
            sbProgress.setProgress(currentPage);
        }

        int bgColor = 0xFFF6F0E3;
        final int textColor; 
        
        int tempTextColor = 0xFF333333;
        if (bgColorIndex == 0) { bgColor = 0xFFFFFFFF; tempTextColor = 0xFF222222; }
        else if (bgColorIndex == 2) { bgColor = 0xFFCCE8CF; tempTextColor = 0xFF2E3A2E; }
        else if (bgColorIndex == 3) { bgColor = 0xFF1A1A1A; tempTextColor = 0xFFA0A0A0; }
        textColor = tempTextColor;
        
        readerRoot.setBackgroundColor(bgColor);

        if (mode == 0) {
            tvPageInfo.setText((currentPage + 1) + " / " + count);
            if (parser.isImageBased()) {
                ImageView iv = new ImageView(this);
                int w = getResources().getDisplayMetrics().widthPixels;
                int h = getResources().getDisplayMetrics().heightPixels;
                Bitmap bmp = parser.getImagePage(currentPage, w, h);
                if (bmp != null) {
                    iv.setImageBitmap(bmp);
                    iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    pageContainer.addView(iv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                }
            } else {
                ScrollView sv = new ScrollView(this);
                TextView tv = new TextView(this);
                tv.setTextColor(textColor);
                tv.setTextSize(fontSize);
                tv.setLineSpacing(0, 1.4f);
                int pad = (int)(16 * getResources().getDisplayMetrics().density);
                tv.setPadding(pad, pad, pad, pad);
                tv.setText(parser.getTextPage(currentPage));
                tv.setTextIsSelectable(true); 
                sv.addView(tv);
                pageContainer.addView(sv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            }
        } else {
            tvPageInfo.setText("滚动阅读中");
            mScrollView = new ScrollView(this);
            mContentLayout = new LinearLayout(this);
            mContentLayout.setOrientation(LinearLayout.VERTICAL);
            mContentLayout.setBackgroundColor(bgColor);
            mScrollView.addView(mContentLayout);
            
            loadedEndPage = currentPage; 
            isLoadingMore = false;
            
            loadMoreContent(count, 3, textColor);

            mScrollView.setOnScrollChangeListener(new View.OnScrollChangeListener() {
                @Override
                public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                    View child = mScrollView.getChildAt(0);
                    if (child != null) {
                        if (!isTracking) {
                            int totalHeight = child.getMeasuredHeight() - mScrollView.getMeasuredHeight();
                            if (totalHeight > 0) {
                                float ratio = (float) scrollY / totalHeight;
                                int visualPage = loadedEndPage - 3 + (int)(ratio * 3); 
                                if(visualPage >= 0 && visualPage < parser.pageCount()) {
                                    currentPage = visualPage;
                                    sbProgress.setProgress(currentPage);
                                    tvPageInfo.setText("约 " + (currentPage + 1) + " 页");
                                }
                            }
                        }
                        
                        if (scrollY >= (child.getMeasuredHeight() - mScrollView.getMeasuredHeight() - 300)) {
                            if (!isLoadingMore && loadedEndPage < parser.pageCount() - 1) {
                                isLoadingMore = true;
                                loadMoreContent(parser.pageCount(), 3, textColor); 
                            }
                        }
                    }
                }
            });

            pageContainer.addView(mScrollView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        }
    }

    private void loadMoreContent(final int totalCount, final int loadSize, final int textColor) {
        final int start = loadedEndPage;
        final int end = Math.min(start + loadSize, totalCount);
        if (start >= end) return;

        final int w = getResources().getDisplayMetrics().widthPixels;
        final int h = getResources().getDisplayMetrics().heightPixels;

        new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = start; i < end; i++) {
                    if (parser.isImageBased()) {
                        final Bitmap bmp = parser.getImagePage(i, w, h);
                        if (bmp != null) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    ImageView iv = new ImageView(ReaderActivity.this);
                                    iv.setImageBitmap(bmp);
                                    iv.setAdjustViewBounds(true);
                                    iv.setScaleType(ImageView.ScaleType.FIT_START);
                                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                                            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                    lp.setMargins(0, -2, 0, 0);
                                    mContentLayout.addView(iv, lp);
                                }
                            });
                        }
                    } else {
                        final String text = parser.getTextPage(i).toString();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                TextView tv = new TextView(ReaderActivity.this);
                                tv.setTextColor(textColor);
                                tv.setTextSize(fontSize);
                                tv.setLineSpacing(0, 1.4f);
                                int pad = (int)(16 * getResources().getDisplayMetrics().density);
                                tv.setPadding(pad, pad, pad, pad);
                                tv.setText(text);
                                tv.setTextIsSelectable(true);
                                mContentLayout.addView(tv);
                            }
                        });
                    }
                }
                loadedEndPage = end;
                isLoadingMore = false;
            }
        }).start();
    }

    private void nextPage() {
        if (parser != null && currentPage < parser.pageCount() - 1) {
            currentPage++;
            renderPage();
        }
    }

    private void prevPage() {
        if (parser != null && currentPage > 0) {
            currentPage--;
            renderPage();
        }
    }

    private void toggleBars() {
        barsVisible = !barsVisible;
        topBar.setVisibility(barsVisible ? View.VISIBLE : View.GONE);
        bottomBar.setVisibility(barsVisible ? View.VISIBLE : View.GONE);
    }

    private List<Book> getUpdatedBooks(Book b) {
        List<Book> allBooks = BookStorage.loadBooks(this);
        for (int i = 0; i < allBooks.size(); i++) {
            if (allBooks.get(i).uri.equals(b.uri)) {
                allBooks.get(i).lastPage = b.lastPage;
                allBooks.get(i).isFavorite = b.isFavorite;
                allBooks.get(i).bookmarks = b.bookmarks;
                allBooks.get(i).lastReadTime = b.lastReadTime;
                allBooks.get(i).totalReadTime = b.totalReadTime;
                break;
            }
        }
        return allBooks;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (parser != null) parser.close();
    }
}