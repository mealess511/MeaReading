package com.Mealess.appaction;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.Mealess.appaction.parser.EpubParser;
import com.Mealess.appaction.parser.Parser;
import com.Mealess.appaction.parser.ParserFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class ReaderActivity extends Activity {

    private FrameLayout pageContainer, readerRoot;
    private LinearLayout topBar, bottomBar;
    private TextView tvTitle, btnShowBookmarks, btnAddBookmark, btnFav, btnToc, btnPrevChapter, btnNextChapter, btnColor, btnPageSettings;
    private SeekBar sbBrightness, sbFontSize, sbProgress;
    private View loadingBar;

    private Parser parser;
    private Book currentBook;
    private int currentPage = 0;
    private int fontSize = 18;
    private boolean barsVisible = false;
    
    private int mode = 0; 
    private boolean isClickReversed = false; 
    private int bgColorIndex = 1; 
    private boolean isClickPagingEnabled = true; 

    private long lastChapterBtnClickTime = 0;

    private GestureDetector gestureDetector;
    private ScaleGestureDetector scaleGestureDetector; 
    private boolean isScaling = false; 
    private boolean isTracking = false;

    private ScrollView mScrollView;
    private LinearLayout mContentLayout;
    private int loadedEndPage = 0;
    private boolean isLoadingMore = false;

    private long readingStartTime = 0;

    private List<Integer> chapterPages = new ArrayList<>();
    private List<String> chapterNames = new ArrayList<>();
    private boolean isTocParsing = false;

    private android.webkit.WebView epubWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reader);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);

        initViews();
        
        final String uri = getIntent().getStringExtra("book_uri");
        String name = getIntent().getStringExtra("book_name");
        
        tvTitle.setText(name);

        List<Book> allBooks = BookStorage.loadBooks(this);
        for (Book b : allBooks) {
            if (b.uri.equals(uri)) {
                currentBook = b;
                break;
            }
        }
        
        final Book safeBook = currentBook;
        
        if (safeBook != null) {
            btnFav.setText(safeBook.isFavorite ? "⭐" : "☆");
        }

        loadingBar.setVisibility(View.VISIBLE);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    int pageChars = 1000;
                    final Parser p = ParserFactory.create(ReaderActivity.this, uri, safeBook.format, pageChars);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            parser = p;
                            currentPage = (safeBook != null) ? safeBook.lastPage : 0;
                            if (currentPage >= parser.pageCount()) currentPage = 0;
                            renderPage();
                            loadingBar.setVisibility(View.GONE);
                            
                            if (parser instanceof EpubParser) {
                                chapterNames.clear();
                                chapterNames.addAll(((EpubParser) parser).getChapterNames());
                                for (int i = 0; i < chapterNames.size(); i++) {
                                    chapterPages.add(i);
                                }
                            } else if (!parser.isImageBased()) {
                                parseChapters();
                            }
                        }
                    });
                } catch (final Throwable t) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            loadingBar.setVisibility(View.GONE);
                            Toast.makeText(ReaderActivity.this, "打开失败：" + t.getMessage(), Toast.LENGTH_LONG).show();
                            finish();
                        }
                    });
                }
            }
        }).start();
    }

    private void initViews() {
        pageContainer = findViewById(R.id.pageContainer);
        readerRoot = findViewById(R.id.readerRoot);
        topBar = findViewById(R.id.topBar);
        bottomBar = findViewById(R.id.bottomBar);
        tvTitle = findViewById(R.id.tvTitle);
        sbBrightness = findViewById(R.id.sbBrightness);
        sbFontSize = findViewById(R.id.sbFontSize);
        sbProgress = findViewById(R.id.sbProgress);
        btnShowBookmarks = findViewById(R.id.btnShowBookmarks);
        btnAddBookmark = findViewById(R.id.btnAddBookmark);
        btnFav = findViewById(R.id.btnFav);
        btnToc = findViewById(R.id.btnToc);
        btnPrevChapter = findViewById(R.id.btnPrevChapter);
        btnNextChapter = findViewById(R.id.btnNextChapter);
        btnColor = findViewById(R.id.btnColor);
        btnPageSettings = findViewById(R.id.btnPageSettings);
        loadingBar = findViewById(R.id.loadingBar);

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });

        btnPrevChapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long now = System.currentTimeMillis();
                if (now - lastChapterBtnClickTime < 500) return; 
                lastChapterBtnClickTime = now;

                if (parser != null && currentPage > 0) {
                    currentPage--;
                    renderPage();
                } else {
                    Toast.makeText(ReaderActivity.this, "已经是第一页了", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnNextChapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long now = System.currentTimeMillis();
                if (now - lastChapterBtnClickTime < 500) return;
                lastChapterBtnClickTime = now;

                if (parser != null && currentPage < parser.pageCount() - 1) {
                    currentPage++;
                    renderPage();
                } else {
                    Toast.makeText(ReaderActivity.this, "已经是最后一页了", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] colors = {"纯白", "羊皮纸", "护眼绿", "夜间黑"};
                new AlertDialog.Builder(ReaderActivity.this)
                    .setTitle("选择背景颜色")
                    .setItems(colors, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            bgColorIndex = which;
                            renderPage();
                        }
                    }).show();
            }
        });

        btnPageSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String[] settings = {
                        mode == 0 ? "切换为: 上下滚动" : "切换为: 左右翻页",
                        isClickPagingEnabled ? "禁用: 点击翻页" : "开启: 点击翻页",
                        isClickReversed ? "点击方向: 左侧下一页" : "点击方向: 右侧下一页"
                };
                new AlertDialog.Builder(ReaderActivity.this)
                    .setTitle("翻页设置")
                    .setItems(settings, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (which == 0) {
                                mode = (mode == 0) ? 1 : 0;
                            } else if (which == 1) {
                                isClickPagingEnabled = !isClickPagingEnabled;
                            } else if (which == 2) {
                                isClickReversed = !isClickReversed;
                            }
                            renderPage();
                        }
                    }).show();
            }
        });

        btnToc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (parser == null) return;
                if (parser.isImageBased()) {
                    Toast.makeText(ReaderActivity.this, "暂不支持目录", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (isTocParsing) {
                    Toast.makeText(ReaderActivity.this, "正在解析目录...", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (chapterNames.isEmpty()) {
                    Toast.makeText(ReaderActivity.this, "未识别到章节", Toast.LENGTH_SHORT).show();
                    return;
                }
                
                String[] display = chapterNames.toArray(new String[0]);
                new AlertDialog.Builder(ReaderActivity.this)
                    .setTitle("目录")
                    .setItems(display, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            currentPage = chapterPages.get(which);
                            renderPage();
                        }
                    }).show();
            }
        });

        btnFav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentBook != null) {
                    currentBook.isFavorite = !currentBook.isFavorite;
                    btnFav.setText(currentBook.isFavorite ? "⭐" : "☆");
                    BookStorage.saveBooks(ReaderActivity.this, getUpdatedBooks(currentBook));
                    Toast.makeText(ReaderActivity.this, currentBook.isFavorite ? "已加入收藏" : "已取消收藏", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnAddBookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentBook != null) {
                    String bm = currentBook.bookmarks == null ? "" : currentBook.bookmarks;
                    if (!bm.contains(String.valueOf(currentPage))) {
                        currentBook.bookmarks = bm.isEmpty() ? String.valueOf(currentPage) : bm + "," + currentPage;
                        BookStorage.saveBooks(ReaderActivity.this, getUpdatedBooks(currentBook));
                        Toast.makeText(ReaderActivity.this, "已添加书签", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(ReaderActivity.this, "已经有书签了", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        btnShowBookmarks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentBook == null || currentBook.bookmarks == null || currentBook.bookmarks.isEmpty()) {
                    Toast.makeText(ReaderActivity.this, "还没有书签哦", Toast.LENGTH_SHORT).show();
                    return;
                }
                final String[] bms = currentBook.bookmarks.split(",");
                String[] display = new String[bms.length];
                for (int i = 0; i < bms.length; i++) {
                    display[i] = "第 " + (Integer.parseInt(bms[i]) + 1) + " 页";
                }
                new AlertDialog.Builder(ReaderActivity.this)
                    .setTitle("选择书签")
                    .setItems(display, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            currentPage = Integer.parseInt(bms[which]);
                            renderPage();
                        }
                    })
                    .setNegativeButton("清空", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            currentBook.bookmarks = "";
                            BookStorage.saveBooks(ReaderActivity.this, getUpdatedBooks(currentBook));
                            Toast.makeText(ReaderActivity.this, "书签已清空", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .show();
            }
        });

        sbProgress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) { 
                    currentPage = progress; 
                    renderPage();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { isTracking = true; }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { isTracking = false; }
        });

        sbBrightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.screenBrightness = Math.max(0.01f, Math.min(1f, progress / 100f));
                getWindow().setAttributes(lp);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        sbFontSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) { fontSize = 12 + progress; renderPage(); }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                if (parser == null) return false;
                int w = getResources().getDisplayMetrics().widthPixels;
                float x = e.getX();
                
                if (x > w * 0.35f && x < w * 0.65f) {
                    toggleBars();
                } else if (mode == 0) {
                    if (isClickPagingEnabled) {
                        if ((x < w * 0.35f && !isClickReversed) || (x > w * 0.65f && isClickReversed)) {
                            prevPage();
                        } else {
                            nextPage();
                        }
                    }
                    if (!barsVisible) toggleBars();
                } else {
                    toggleBars(); 
                }
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                if (e1 == null || e2 == null || mode == 1 || parser == null) return false;
                if (isScaling) return false; 
                
                float dx = e2.getX() - e1.getX();
                float dy = e2.getY() - e1.getY();
                if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 80) {
                    boolean isSwipeLeft = dx < 0;
                    if (isSwipeLeft) {
                        if (!isClickReversed) nextPage(); else prevPage();
                    } else {
                        if (!isClickReversed) prevPage(); else nextPage();
                    }
                    return true;
                }
                return false;
            }
        });

        scaleGestureDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                if (parser instanceof EpubParser) return false;
                
                if (parser != null && !parser.isImageBased()) {
                    float factor = detector.getScaleFactor();
                    int newSize = (int) (fontSize * factor);
                    if (newSize > 42) newSize = 42;
                    if (newSize < 12) newSize = 12;
                    if (newSize != fontSize) {
                        fontSize = newSize;
                        sbFontSize.setProgress(fontSize - 12);
                        renderPage();
                    }
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        // 菜单区域直接放行
        if (barsVisible) {
            if (bottomBar.getVisibility() == View.VISIBLE) {
                int[] loc = new int[2];
                bottomBar.getLocationOnScreen(loc);
                if (ev.getRawY() >= loc[1]) return super.dispatchTouchEvent(ev);
            }
            if (topBar.getVisibility() == View.VISIBLE) {
                int[] loc = new int[2];
                topBar.getLocationOnScreen(loc);
                if (ev.getRawY() <= loc[1] + topBar.getHeight()) return super.dispatchTouchEvent(ev);
            }
        }

        // 🚀 核心修复：如果检测到多根手指，不要去拦截它，直接放行让底下的 ImageView 或 WebView 接收缩放事件
        if (ev.getPointerCount() > 1) {
            isScaling = true;
            if (scaleGestureDetector != null) scaleGestureDetector.onTouchEvent(ev);
            // 🚀 注意这里：返回 super 让它传给底层的控件，千万别 return true
            return super.dispatchTouchEvent(ev); 
        }
        
        if (ev.getAction() == MotionEvent.ACTION_UP) {
            isScaling = false;
        }

        if (gestureDetector != null && gestureDetector.onTouchEvent(ev)) return true;
        return super.dispatchTouchEvent(ev);
    }

    private void parseChapters() {
        isTocParsing = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<Integer> pages = new ArrayList<>();
                final List<String> names = new ArrayList<>();
                Pattern pattern = Pattern.compile("^\\s*第[0-9一二三四五六七八九十百千万]+[章回节卷].*");
                
                int count = parser.pageCount();
                for (int i = 0; i < count; i++) {
                    String text = parser.getTextPage(i).toString();
                    String[] lines = text.split("\n");
                    for (String line : lines) {
                        line = line.trim();
                        if (pattern.matcher(line).matches()) {
                            pages.add(i);
                            names.add(line);
                            break;
                        }
                    }
                }
                
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        chapterPages.clear();
                        chapterPages.addAll(pages);
                        chapterNames.clear();
                        chapterNames.addAll(names);
                        isTocParsing = false;
                    }
                });
            }
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        readingStartTime = System.currentTimeMillis();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (currentBook != null && parser != null) {
            long cost = System.currentTimeMillis() - readingStartTime;
            if (cost > 0 && cost < 4 * 60 * 60 * 1000) {
                currentBook.totalReadTime += cost;
            }
            
            currentBook.lastPage = currentPage;
            currentBook.lastReadTime = System.currentTimeMillis();
            BookStorage.saveBooks(this, getUpdatedBooks(currentBook));
        }
    }

    private void renderPage() {
        pageContainer.removeAllViews();
        if (parser == null) return;
        int count = parser.pageCount();
        if (count == 0) return;
        if (currentPage < 0) currentPage = 0;
        if (currentPage >= count) currentPage = count - 1;

        if (!isTracking) {
            sbProgress.setMax(count - 1);
            sbProgress.setProgress(currentPage);
        }

        int bgColor = 0xFFF6F0E3;
        final int textColor; 
        
        int tempTextColor = 0xFF333333;
        if (bgColorIndex == 0) { bgColor = 0xFFFFFFFF; tempTextColor = 0xFF222222; }
        else if (bgColorIndex == 2) { bgColor = 0xFFCCE8CF; tempTextColor = 0xFF2E3A2E; }
        else if (bgColorIndex == 3) { bgColor = 0xFF1A1A1A; tempTextColor = 0xFFA0A0A0; }
        textColor = tempTextColor;
        
        readerRoot.setBackgroundColor(bgColor);

        if (parser instanceof EpubParser) {
            EpubParser ep = (EpubParser) parser;
            
            if (epubWebView == null) {
                epubWebView = new android.webkit.WebView(this);
                epubWebView.getSettings().setAllowFileAccess(true);
                epubWebView.getSettings().setAllowFileAccessFromFileURLs(true);
                epubWebView.getSettings().setAllowUniversalAccessFromFileURLs(true);
                epubWebView.getSettings().setJavaScriptEnabled(true);
                epubWebView.getSettings().setSupportZoom(true);
                epubWebView.getSettings().setBuiltInZoomControls(true);
                epubWebView.getSettings().setDisplayZoomControls(false); 
                epubWebView.setInitialScale(100); 
            }
            
            epubWebView.setBackgroundColor(bgColor);
            
            String path = ep.getHtmlPath(currentPage);
            String htmlContent = ep.getHtmlContent(currentPage);
            
            final String textColorHex = String.format("#%06X", (0xFFFFFF & textColor));
            final String fontSizeStr = fontSize + "px";
            
            boolean isComicPage = false;
            if (htmlContent != null) {
                String pureText = htmlContent.replaceAll("<[^>]+>", "").trim();
                if (pureText.length() < 50 && htmlContent.contains("<img")) {
                    isComicPage = true;
                }
            }

            String style;
            if (isComicPage) {
                style = "<style>" +
                        "html, body { margin: 0; padding: 0; width: 100%; height: 100vh; " +
                        "background-color: transparent !important; " +
                        "display: flex; align-items: center; justify-content: center; } " +
                        "img { max-width: 100% !important; max-height: 100vh !important; object-fit: contain !important; display: block; } " +
                        "</style>";
            } else {
                style = "<style>" +
                        "html, body { margin: 0; padding: 0; width: 100%; min-height: 100%; " +
                        "background-color: transparent !important; " +
                        "color: " + textColorHex + " !important; font-size: " + fontSizeStr + " !important; line-height: 1.8 !important; text-align: justify !important; } " +
                        "p { width: 100%; text-indent: 2em; margin: 0 0 1em 0; padding: 0 !important; } " +
                        "img { max-width: 100% !important; height: auto !important; margin: 10px auto; display: block; } " +
                        "body { padding: 32px !important; box-sizing: border-box; } " + 
                        "</style>";
            }
            
            if (htmlContent != null && htmlContent.contains("</head>")) {
                htmlContent = htmlContent.replace("</head>", style + "</head>");
            } else {
                htmlContent = style + htmlContent;
            }

            String baseUrl = "file://" + new File(path).getParent() + "/";
            epubWebView.loadDataWithBaseURL(baseUrl, htmlContent, "text/html", "UTF-8", null);
            
            pageContainer.addView(epubWebView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            return;
        }

        if (mode == 0) {
            if (parser.isImageBased()) {
                ZoomImageView iv = new ZoomImageView(this);
                int w = getResources().getDisplayMetrics().widthPixels;
                int h = getResources().getDisplayMetrics().heightPixels;
                Bitmap bmp = parser.getImagePage(currentPage, w, h);
                if (bmp != null) {
                    iv.setImageBitmap(bmp);
                    pageContainer.addView(iv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                }
            } else {
                TextView tv = new TextView(this);
                tv.setTextColor(textColor);
                tv.setTextSize(fontSize);
                tv.setLineSpacing(0, 1.4f);
                int pad = (int)(16 * getResources().getDisplayMetrics().density);
                tv.setPadding(pad, pad, pad, pad);
                tv.setText(parser.getTextPage(currentPage));
                tv.setTextIsSelectable(true); 
                pageContainer.addView(tv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            }
        } else {
            mScrollView = new ScrollView(this);
            mContentLayout = new LinearLayout(this);
            mContentLayout.setOrientation(LinearLayout.VERTICAL);
            mContentLayout.setBackgroundColor(bgColor);
            mScrollView.addView(mContentLayout);
            
            loadedEndPage = currentPage; 
            isLoadingMore = false;
            
            loadMoreContent(count, 3, textColor);

            mScrollView.setOnScrollChangeListener(new View.OnScrollChangeListener() {
                @Override
                public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                    View child = mScrollView.getChildAt(0);
                    if (child != null) {
                        if (!isTracking) {
                            int totalHeight = child.getMeasuredHeight() - mScrollView.getMeasuredHeight();
                            if (totalHeight > 0) {
                                float ratio = (float) scrollY / totalHeight;
                                int visualPage = loadedEndPage - 3 + (int)(ratio * 3); 
                                if(visualPage >= 0 && visualPage < parser.pageCount()) {
                                    currentPage = visualPage;
                                    sbProgress.setProgress(currentPage);
                                }
                            }
                        }
                        
                        if (scrollY >= (child.getMeasuredHeight() - mScrollView.getMeasuredHeight() - 300)) {
                            if (!isLoadingMore && loadedEndPage < parser.pageCount() - 1) {
                                isLoadingMore = true;
                                loadMoreContent(parser.pageCount(), 3, textColor); 
                            }
                        }
                    }
                }
            });

            pageContainer.addView(mScrollView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        }
    }

    private void loadMoreContent(final int totalCount, final int loadSize, final int textColor) {
        final int start = loadedEndPage;
        final int end = Math.min(start + loadSize, totalCount);
        if (start >= end) return;

        final int w = getResources().getDisplayMetrics().widthPixels;
        final int h = getResources().getDisplayMetrics().heightPixels;

        new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = start; i < end; i++) {
                    if (parser.isImageBased()) {
                        final Bitmap bmp = parser.getImagePage(i, w, h);
                        if (bmp != null) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    ZoomImageView iv = new ZoomImageView(ReaderActivity.this);
                                    iv.setImageBitmap(bmp);
                                    iv.setAdjustViewBounds(true);
                                    iv.setScaleType(android.widget.ImageView.ScaleType.FIT_START);
                                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                                            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                    lp.setMargins(0, -2, 0, 0);
                                    mContentLayout.addView(iv, lp);
                                }
                            });
                        }
                    } else {
                        final String text = parser.getTextPage(i).toString();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                TextView tv = new TextView(ReaderActivity.this);
                                tv.setTextColor(textColor);
                                tv.setTextSize(fontSize);
                                tv.setLineSpacing(0, 1.4f);
                                int pad = (int)(16 * getResources().getDisplayMetrics().density);
                                tv.setPadding(pad, pad, pad, pad);
                                tv.setText(text);
                                tv.setTextIsSelectable(true);
                                mContentLayout.addView(tv);
                            }
                        });
                    }
                }
                loadedEndPage = end;
                isLoadingMore = false;
            }
        }).start();
    }

    private void nextPage() {
        if (parser instanceof EpubParser && epubWebView != null) {
            boolean scrolled = epubWebView.pageDown(false);
            if (!scrolled) {
                if (parser != null && currentPage < parser.pageCount() - 1) {
                    currentPage++;
                    renderPage();
                }
            }
            return;
        }

        if (parser != null && currentPage < parser.pageCount() - 1) {
            currentPage++;
            renderPage();
        }
    }

    private void prevPage() {
        if (parser instanceof EpubParser && epubWebView != null) {
            boolean scrolled = epubWebView.pageUp(false);
            if (!scrolled) {
                if (parser != null && currentPage > 0) {
                    currentPage--;
                    renderPage();
                }
            }
            return;
        }

        if (parser != null && currentPage > 0) {
            currentPage--;
            renderPage();
        }
    }

    private void toggleBars() {
        barsVisible = !barsVisible;
        topBar.setVisibility(barsVisible ? View.VISIBLE : View.GONE);
        bottomBar.setVisibility(barsVisible ? View.VISIBLE : View.GONE);
    }

    private List<Book> getUpdatedBooks(Book b) {
        List<Book> allBooks = BookStorage.loadBooks(this);
        for (int i = 0; i < allBooks.size(); i++) {
            if (allBooks.get(i).uri.equals(b.uri)) {
                allBooks.get(i).lastPage = b.lastPage;
                allBooks.get(i).isFavorite = b.isFavorite;
                allBooks.get(i).bookmarks = b.bookmarks;
                allBooks.get(i).lastReadTime = b.lastReadTime;
                allBooks.get(i).totalReadTime = b.totalReadTime;
                break;
            }
        }
        return allBooks;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (epubWebView != null) {
            epubWebView.destroy();
            epubWebView = null;
        }
        if (parser != null) parser.close();
    }
}