package com.Mealess.appaction;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

public class ZoomImageView extends ImageView {
    private Matrix matrix = new Matrix();
    private float scale = 1f;
    private ScaleGestureDetector scaleDetector;
    private GestureDetector gestureDetector;
    private PointF last = new PointF();

    public ZoomImageView(Context context) {
        super(context);
        init(context);
    }

    public ZoomImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        super.setClickable(true);
        this.setScaleType(ScaleType.MATRIX);
        scaleDetector = new ScaleGestureDetector(context, new ScaleListener());
        gestureDetector = new GestureDetector(context, new GestureListener());
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        gestureDetector.onTouchEvent(event);
        
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            last.set(event.getX(), event.getY());
        } else if (event.getAction() == MotionEvent.ACTION_MOVE && event.getPointerCount() == 1) {
            float dx = event.getX() - last.x;
            float dy = event.getY() - last.y;
            matrix.postTranslate(dx, dy);
            setImageMatrix(matrix);
            last.set(event.getX(), event.getY());
        }
        // 🚀 返回 true 告诉系统这个控件需要处理触摸事件
        return true;
    }

    private class GestureListener extends GestureDetector.SimpleOnGestureListener {
        @Override
        public boolean onDoubleTap(MotionEvent e) {
            scale = 1f;
            matrix.reset();
            setImageMatrix(matrix);
            return true;
        }
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            float factor = detector.getScaleFactor();
            float newScale = scale * factor;
            if (newScale > 3f) factor = 3f / scale; 
            if (newScale < 1f) factor = 1f / scale; 
            scale *= factor;
            matrix.postScale(factor, factor, detector.getFocusX(), detector.getFocusY());
            setImageMatrix(matrix);
            return true;
        }
    }
}