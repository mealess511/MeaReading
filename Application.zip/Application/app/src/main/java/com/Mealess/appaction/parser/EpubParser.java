package com.Mealess.appaction.parser;

import android.graphics.Bitmap;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class EpubParser implements Parser {
    private final List<String> htmlPaths = new ArrayList<>();
    private final List<String> chapterNames = new ArrayList<>();
    private final File extractDir;
    private final ZipFile zipFile;

    public EpubParser(ZipFile zipFile, File cacheDir) throws IOException {
        this.zipFile = zipFile;
        this.extractDir = new File(cacheDir, "epub_temp_" + System.currentTimeMillis());
        if (!extractDir.exists()) extractDir.mkdirs();
        extractAll();
        findHtmlFiles();
    }

    private void extractAll() throws IOException {
        Enumeration<? extends ZipEntry> en = zipFile.entries();
        while (en.hasMoreElements()) {
            ZipEntry entry = en.nextElement();
            File file = new File(extractDir, entry.getName());
            if (entry.isDirectory()) {
                file.mkdirs();
            } else {
                File parent = file.getParentFile();
                if (parent != null && !parent.exists()) parent.mkdirs();
                InputStream is = zipFile.getInputStream(entry);
                FileOutputStream fos = new FileOutputStream(file);
                byte[] buf = new byte[8192];
                int n;
                while ((n = is.read(buf)) != -1) fos.write(buf, 0, n);
                is.close();
                fos.close();
            }
        }
    }

    private void findHtmlFiles() {
        File opfFile = findOpfFile(extractDir);
        if (opfFile != null) {
            parseOpf(opfFile);
        }

        // 兜底：如果 OPF 没找到或者解析失败，直接全盘扫描并按自然顺序排
        if (htmlPaths.isEmpty()) {
            scanDir(extractDir);
            Collections.sort(htmlPaths, new Comparator<String>() {
                @Override public int compare(String s1, String s2) {
                    return s1.compareToIgnoreCase(s2);
                }
            });
        }

        // 为每一个网页提取标题（作为目录）
        for (String path : htmlPaths) {
            chapterNames.add(extractTitle(new File(path)));
        }
    }

    private File findOpfFile(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return null;
        for (File f : files) {
            if (f.isDirectory()) {
                File found = findOpfFile(f);
                if (found != null) return found;
            } else if (f.getName().toLowerCase().endsWith(".opf")) {
                return f;
            }
        }
        return null;
    }

    private void parseOpf(File opfFile) {
        try {
            StringBuilder sb = new StringBuilder();
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(opfFile), "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            String opfText = sb.toString();
            
            // 获取 OPF 所在目录
            String opfDirPath = opfFile.getParent();
            
            // 1. 从 manifest 里提取 id 和 href 的映射
            Map<String, String> idToHref = new HashMap<>();
            Pattern itemPattern = Pattern.compile("(?i)<item\\s+[^>]*>");
            Matcher itemMatcher = itemPattern.matcher(opfText);
            while (itemMatcher.find()) {
                String itemTag = itemMatcher.group();
                String id = extractAttribute(itemTag, "id");
                String href = extractAttribute(itemTag, "href");
                if (id != null && href != null) {
                    idToHref.put(id, href);
                }
            }

            // 2. 从 spine 里按顺序提取 idref
            Pattern itemrefPattern = Pattern.compile("(?i)<itemref\\s+[^>]*>");
            Matcher itemrefMatcher = itemrefPattern.matcher(opfText);
            while (itemrefMatcher.find()) {
                String itemrefTag = itemrefMatcher.group();
                String idref = extractAttribute(itemrefTag, "idref");
                if (idref != null && idToHref.containsKey(idref)) {
                    String href = idToHref.get(idref);
                    try { href = java.net.URLDecoder.decode(href, "UTF-8"); } catch (Exception ignored) {}
                    
                    // 拼接成绝对路径
                    File htmlFile = new File(opfDirPath, href);
                    if (htmlFile.exists()) {
                        htmlPaths.add(htmlFile.getAbsolutePath());
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private String extractAttribute(String tag, String attrName) {
        Pattern p = Pattern.compile("(?i)" + attrName + "\\s*=\\s*[\"']([^\"']+)[\"']");
        Matcher m = p.matcher(tag);
        if (m.find()) return m.group(1);
        return null;
    }

    private void scanDir(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) scanDir(f);
            else {
                String name = f.getName().toLowerCase();
                if (name.endsWith(".html") || name.endsWith(".xhtml") || name.endsWith(".htm")) {
                    htmlPaths.add(f.getAbsolutePath());
                }
            }
        }
    }

    private String extractTitle(File htmlFile) {
        StringBuilder sb = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(htmlFile), "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) { sb.append(line); }
            br.close();
            String content = sb.toString();
            
            Matcher m = Pattern.compile("(?i)<title>(.*?)</title>").matcher(content);
            if (m.find()) {
                String title = m.group(1).trim();
                if (!title.isEmpty()) return title;
            }
            m = Pattern.compile("(?i)<h[1-3][^>]*>(.*?)</h[1-3]>").matcher(content);
            if (m.find()) {
                return m.group(1).replaceAll("<[^>]+>", "").trim();
            }
        } catch (Exception ignored) {}
        return "未知章节";
    }

    public String getHtmlPath(int index) {
        if (index < 0 || index >= htmlPaths.size()) return null;
        return htmlPaths.get(index);
    }

    public String getHtmlContent(int index) {
        if (index < 0 || index >= htmlPaths.size()) return "";
        StringBuilder sb = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(htmlPaths.get(index)), "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) { sb.append(line).append("\n"); }
            br.close();
        } catch (Exception ignored) {}
        return sb.toString();
    }

    public List<String> getChapterNames() {
        return chapterNames;
    }

    @Override public boolean isImageBased() { return false; }
    @Override public int pageCount() { return htmlPaths.size(); }
    @Override public CharSequence getTextPage(int index) { return ""; }
    @Override public Bitmap getImagePage(int index, int w, int h) { return null; }

    @Override
    public void close() {
        try { zipFile.close(); } catch (Exception ignored) {}
        deleteDir(extractDir);
    }

    private void deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            File[] files = dir.listFiles();
            if (files != null) { for (File f : files) deleteDir(f); }
        }
        if (dir != null) dir.delete();
    }
}