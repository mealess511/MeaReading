package com.Mealess.appaction.parser;

import android.graphics.Bitmap;

public interface Parser {
    boolean isImageBased();
    int pageCount();
    CharSequence getTextPage(int index);
    Bitmap getImagePage(int index, int width, int height);
    void close();
}