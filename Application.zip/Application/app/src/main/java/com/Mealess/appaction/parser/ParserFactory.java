package com.Mealess.appaction.parser;

import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.zip.ZipFile;

public class ParserFactory {
    public static Parser create(Context c, String uriString, String format, int pageChars) throws Exception {
        Uri uri = Uri.parse(uriString);
        String ext = format == null ? "" : format.toLowerCase();

        if ("txt".equals(ext) || "log".equals(ext) || "md".equals(ext)) {
            InputStream in = c.getContentResolver().openInputStream(uri);
            return new TxtParser(in, pageChars);
        }

        if ("pdf".equals(ext)) {
            if (Build.VERSION.SDK_INT < 21) throw new RuntimeException("PDF 阅读需 Android 5.0+");
            ParcelFileDescriptor pfd = c.getContentResolver().openFileDescriptor(uri, "r");
            if (pfd == null) throw new RuntimeException("无法打开 PDF");
            return new PdfParser(pfd);
        }

        if ("zip".equals(ext) || "epub".equals(ext) || "cbz".equals(ext)) {
            // 🚀 注意：这里的文件复制操作会在 ReaderActivity 的子线程中运行，不会卡死主屏幕
            File tmp = new File(c.getCacheDir(), "tmp_" + System.currentTimeMillis() + ".zip");
            InputStream in = c.getContentResolver().openInputStream(uri);
            FileOutputStream fo = new FileOutputStream(tmp);
            try {
                byte[] buf = new byte[16384]; // 加大 Buffer 加快复制
                int n;
                while ((n = in.read(buf)) != -1) fo.write(buf, 0, n);
            } finally {
                if (in != null) in.close();
                fo.close();
            }
            return new ZipParser(new ZipFile(tmp), pageChars);
        }

        if ("mobi".equals(ext) || "azw3".equals(ext)) {
            throw new RuntimeException("暂不支持 MOBI，请转换为 EPUB 或 TXT。");
        }

        throw new RuntimeException("不支持的文件格式：." + ext);
    }
}