package com.Mealess.appaction.parser;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import java.io.IOException;

public class PdfParser implements Parser {
    private PdfRenderer renderer;
    private ParcelFileDescriptor pfd;

    public PdfParser(ParcelFileDescriptor pfd) throws IOException {
        this.pfd = pfd;
        this.renderer = new PdfRenderer(pfd);
    }

    @Override public boolean isImageBased() { return true; }
    @Override public int pageCount() { return renderer.getPageCount(); }
    @Override public CharSequence getTextPage(int index) { return ""; }

    @Override
    public Bitmap getImagePage(int index, int screenWidth, int screenHeight) {
        if (index < 0 || index >= renderer.getPageCount()) return null;
        PdfRenderer.Page page = null;
        Bitmap bmp = null;
        try {
            page = renderer.openPage(index);
            
            // 获取 PDF 原本的真实宽高比例
            int originalWidth = page.getWidth();
            int originalHeight = page.getHeight();
            
            // 以屏幕宽度为基准，等比计算出渲染高度
            float ratio = (float) originalWidth / screenWidth;
            int targetWidth = screenWidth;
            int targetHeight = (int) (originalHeight / ratio);
            
            bmp = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
            bmp.eraseColor(Color.WHITE);
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
        } catch (Exception e) {
            if (bmp != null) { bmp.recycle(); bmp = null; }
        } finally {
            if (page != null) page.close();
        }
        return bmp;
    }

    @Override
    public void close() {
        try { renderer.close(); } catch (Exception ignored) {}
        try { pfd.close(); } catch (Exception ignored) {}
    }
}