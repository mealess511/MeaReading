package com.Mealess.appaction.parser;

import android.graphics.Bitmap;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class TxtParser implements Parser {
    private final List<String> pages = new ArrayList<>();

    public TxtParser(InputStream in, int pageChars) throws IOException {
        String content = readAll(in);
        if (content.length() > 0 && content.charAt(0) == '\uFEFF') content = content.substring(1);
        content = content.replace("\0", "").replace("\r\n", "\n");
        
        if (content.isEmpty()) {
            pages.add("（空文件）");
        } else {
            int len = content.length();
            int size = Math.max(200, pageChars);
            for (int i = 0; i < len; i += size) {
                pages.add(content.substring(i, Math.min(len, i + size)));
            }
        }
    }

    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        byte[] data = out.toByteArray();
        
        String utf8Str = new String(data, "UTF-8");
        if (utf8Str.contains("\uFFFD")) {
            try { return new String(data, "GBK"); } catch (Exception e) { return utf8Str; }
        }
        return utf8Str;
    }

    @Override public boolean isImageBased() { return false; }
    @Override public int pageCount() { return pages.size(); }
    @Override public CharSequence getTextPage(int index) { return (index >= 0 && index < pages.size()) ? pages.get(index) : ""; }
    @Override public Bitmap getImagePage(int index, int w, int h) { return null; }
    @Override public void close() {}
}