package com.Mealess.appaction.parser;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ZipParser implements Parser {
    private final List<String> textPages = new ArrayList<>();
    private final List<ZipEntry> imageEntries = new ArrayList<>();
    private final ZipFile zipFile;
    private final boolean isImageMode;

    public ZipParser(ZipFile zipFile, int pageChars) throws IOException {
        this.zipFile = zipFile;
        
        List<ZipEntry> htmlEntries = new ArrayList<>();
        Map<String, ZipEntry> allImages = new HashMap<>();
        Map<String, ZipEntry> allFiles = new HashMap<>();
        
        Enumeration<? extends ZipEntry> en = zipFile.entries();
        while (en.hasMoreElements()) {
            ZipEntry e = en.nextElement();
            if (e.isDirectory()) continue;
            String n = e.getName().toLowerCase();
            allFiles.put(n, e);
            
            // 收集所有的网页
            if (n.endsWith(".html") || n.endsWith(".htm") || n.endsWith(".xhtml")) {
                htmlEntries.add(e);
            } 
            // 收集所有的图片
            else if (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp")) {
                allImages.put(n, e);
            }
        }

        // 🚀 核心修复 1：严格按文件名的自然顺序排序 HTML（解决 1.html, 10.html, 2.html 的顺序问题）
        Collections.sort(htmlEntries, new NaturalOrderComparator());
        
        List<ZipEntry> orderedImages = new ArrayList<>();
        StringBuilder allText = new StringBuilder();
        
        // 🚀 核心修复 2：按 HTML 的绝对顺序，顺着网页里的标签抠图
        if (!htmlEntries.isEmpty()) {
            for (ZipEntry html : htmlEntries) {
                try {
                    String htmlText = readAll(zipFile.getInputStream(html));
                    List<String> imgSrcs = extractImgSrcs(htmlText);
                    for (String src : imgSrcs) {
                        String realPath = resolvePath(html.getName(), src).toLowerCase();
                        if (allImages.containsKey(realPath)) {
                            orderedImages.add(allImages.get(realPath));
                            allImages.remove(realPath);
                        }
                    }
                    String pureText = cleanHtml(htmlText);
                    if (pureText.length() > 10) allText.append(pureText).append("\n\n");
                } catch (Exception ignored) {}
            }
        }
        
        // 如果有的图片没有被 HTML 引用（比如封面），放在最后
        if (!allImages.isEmpty()) {
            List<ZipEntry> remainImages = new ArrayList<>(allImages.values());
            Collections.sort(remainImages, new NaturalOrderComparator());
            orderedImages.addAll(remainImages);
        }

        String content = allText.toString().trim();
        
        // 判定为漫画
        if (!orderedImages.isEmpty() && (content.isEmpty() || content.length() < 1000)) {
            isImageMode = true;
            imageEntries.addAll(orderedImages);
        } else {
            isImageMode = false;
            if (content.isEmpty()) textPages.add("[未找到可读内容]");
            else {
                int len = content.length(); int size = Math.max(200, pageChars);
                for (int i = 0; i < len; i += size) textPages.add(content.substring(i, Math.min(len, i + size)));
            }
        }
    }

    // 🚀 暴力破解路径，处理 ../ 等乱码
    private String resolvePath(String htmlPath, String src) {
        if (src.startsWith("http")) return src;
        try { src = java.net.URLDecoder.decode(src, "UTF-8"); } catch (Exception ignored) {}
        String dir = htmlPath.contains("/") ? htmlPath.substring(0, htmlPath.lastIndexOf('/') + 1) : "";
        String full = dir + src;
        while (full.contains("../")) {
            int idx = full.indexOf("../");
            int prevSlash = full.lastIndexOf('/', idx - 2);
            full = prevSlash != -1 ? full.substring(0, prevSlash + 1) + full.substring(idx + 3) : full.substring(idx + 3);
        }
        return full.replace("/./", "/");
    }

    private List<String> extractImgSrcs(String html) {
        List<String> srcs = new ArrayList<>();
        Matcher m = Pattern.compile("(?i)<img\\s+[^>]*src\\s*=\\s*[\"']([^\"']+)[\"']").matcher(html);
        while (m.find()) srcs.add(m.group(1));
        return srcs;
    }

    private String cleanHtml(String s) {
        return s.replaceAll("(?i)<head.*?</head>", "").replaceAll("(?i)<script.*?</script>", "").replaceAll("(?i)<style.*?</style>", "").replaceAll("<[^>]+>", " ").replace("&nbsp;", " ").replaceAll("\\s+", " ").trim();
    }

    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buf = new byte[8192]; int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        return out.toString("UTF-8");
    }

    private static class NaturalOrderComparator implements Comparator<ZipEntry> {
        @Override public int compare(ZipEntry o1, ZipEntry o2) {
            String s1 = o1.getName(); String s2 = o2.getName(); 
            int i = 0, j = 0, len1 = s1.length(), len2 = s2.length();
            while (i < len1 && j < len2) {
                char c1 = s1.charAt(i); char c2 = s2.charAt(j);
                if (Character.isDigit(c1) && Character.isDigit(c2)) {
                    int num1 = 0, num2 = 0;
                    while (i < len1 && Character.isDigit(s1.charAt(i))) { num1 = num1 * 10 + (s1.charAt(i) - '0'); i++; }
                    while (j < len2 && Character.isDigit(s2.charAt(j))) { num2 = num2 * 10 + (s2.charAt(j) - '0'); j++; }
                    if (num1 != num2) return Integer.compare(num1, num2);
                } else { if (c1 != c2) return Character.compare(c1, c2); i++; j++; }
            }
            return Integer.compare(len1, len2);
        }
    }

    @Override public boolean isImageBased() { return isImageMode; }
    @Override public int pageCount() { return isImageMode ? imageEntries.size() : textPages.size(); }
    @Override public CharSequence getTextPage(int index) { return (isImageMode || index < 0 || index >= textPages.size()) ? "" : textPages.get(index); }

    @Override public Bitmap getImagePage(int index, int w, int h) {
        if (!isImageMode || index < 0 || index >= imageEntries.size()) return null;
        try {
            ZipEntry entry = imageEntries.get(index); 
            InputStream is = zipFile.getInputStream(entry);
            BitmapFactory.Options opts = new BitmapFactory.Options(); 
            opts.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(is, null, opts); 
            is.close();
            int inSampleSize = 1;
            if (opts.outWidth > w) {
                inSampleSize = opts.outWidth / w;
                if (inSampleSize < 1) inSampleSize = 1;
            }
            opts.inSampleSize = inSampleSize; 
            opts.inJustDecodeBounds = false;
            is = zipFile.getInputStream(entry); 
            Bitmap bmp = BitmapFactory.decodeStream(is, null, opts); 
            is.close();
            return bmp;
        } catch (Throwable e) { return null; }
    }

    @Override public void close() { try { zipFile.close(); } catch (Exception ignored) {} }
}